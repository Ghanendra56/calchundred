class  Accha():
    def __init__(self):
        print("This is a Constructor")

    def acchafunc(self, number):
        print("The Number you types is shown below.")
        return number

