import time

# class  calc():
#     def __init__(self):
#         print("Maded a Constructor")

import asyncio


def calccal():
    number1 = int(input("Enter a number: "))
    number2 = int(input("Enter another number: "))

    print(".")
    time.sleep(2)
    print("..")
    time.sleep(3)
    print("...")
    time.sleep(4)
    print("....")
    time.sleep(5)

    result = ("The total of Number1 and Number2 is: ", number1 + number2)
    print(result)
