class  Accha():
    def __init__():
        print("Constructor baan gaya!")

    def acchafunc(number):
        print("This is a Function!")
        return number

