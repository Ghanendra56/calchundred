from setuptools import setup
setup(name="packagearinjoyn",
version="0.4",
description="This is Arinjoy's Python Package!",
long_description="This is a very bery long description!",
author="Arinjoy",
packages=['packagearinjoyn'],
install_requires=[])