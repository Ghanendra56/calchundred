def acchafunc(number):
    print("This is a Function!")
    return number

